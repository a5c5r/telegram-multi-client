# Telegram Multi-Client

مكتبة بايثون للتحكم بحسابات تلجرام متعددة بأوامر عربية.

## 📥 التثبيت

```bash
pip install telegram-multi-client