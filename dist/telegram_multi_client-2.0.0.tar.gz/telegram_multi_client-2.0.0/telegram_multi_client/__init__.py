"""
Telegram Multi-Client - مكتبة متعددة الحسابات بأوامر عربية
"""

__version__ = "2.0.0"
__author__ = "Your Name"

print(f"✅ Telegram Multi-Client v{__version__} loaded")
